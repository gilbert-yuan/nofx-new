import { summarizeIndicators } from '../indicators/core.js';
import { structure } from '../analysis/structure.js';
import { mean } from '../utils.js';
export function backtest(candles,{fee=.0005,slippage=.0003}={}){
  const trades=[];
  for(let i=220;i<candles.length-12;i++){
    const view=candles.slice(0,i+1), ind=summarizeIndicators(view), s=structure(view);
    if(!(s.trend==='BEARISH'&&ind.price<ind.ema20&&ind.ema20<ind.ema50&&ind.rsi>30))continue;
    const entry=ind.price*(1-slippage), stop=entry+ind.atr*1.2, target=entry-ind.atr*2.4; let exit=candles[i+12].close, reason='TIME';
    for(const bar of candles.slice(i+1,i+13)){ if(bar.high>=stop){exit=stop;reason='SL';break;} if(bar.low<=target){exit=target;reason='TP';break;} }
    const gross=(entry-exit)/entry, net=gross-fee*2-slippage; trades.push({entryIndex:i,entry,exit,reason,netR:net/((stop-entry)/entry)}); i+=3;
  }
  const wins=trades.filter(t=>t.netR>0), losses=trades.filter(t=>t.netR<=0), totalR=trades.reduce((s,t)=>s+t.netR,0); let equity=0,peak=0,maxDD=0;
  for(const t of trades){equity+=t.netR;peak=Math.max(peak,equity);maxDD=Math.max(maxDD,peak-equity);}
  return {totalTrades:trades.length,winRate:trades.length?wins.length/trades.length:0,averageWin:mean(wins.map(x=>x.netR))||0,averageLoss:mean(losses.map(x=>x.netR))||0,profitFactor:Math.abs(losses.reduce((s,t)=>s+t.netR,0))?wins.reduce((s,t)=>s+t.netR,0)/Math.abs(losses.reduce((s,t)=>s+t.netR,0)):null,expectancy:trades.length?totalR/trades.length:0,maxDrawdownR:maxDD,totalR,trades};
}
