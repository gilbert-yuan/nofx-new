import { clamp } from '../utils.js';
export function makeTradePlan({price,atr,resistance,support,balance,risk,volatility,leverage=5}) {
  resistance=resistance&&resistance>price?resistance:price+atr*.8;
  support=support&&support<price?support:price-atr*2;
  const entryLow=Math.max(price,resistance-atr*.25), entryHigh=resistance+atr*.15, entry=(entryLow+entryHigh)/2;
  const stopLoss=resistance+atr*.35, riskDistance=stopLoss-entry;
  const tp1=Math.min(support,entry-riskDistance), tp2=entry-riskDistance*2, tp3=entry-riskDistance*3;
  const riskReward=(entry-tp2)/riskDistance;
  const volFactor=volatility>.9?.5:volatility>.8?.7:1, adjustedRisk=clamp(risk*volFactor,0,.02);
  const riskAmount=balance*adjustedRisk, stopPercent=riskDistance/entry, notional=riskAmount/stopPercent;
  leverage=clamp(leverage,1,20);
  const maintenanceMarginRateEstimate=.005;
  const estimatedLiquidationPrice=entry*(1+1/leverage-maintenanceMarginRateEstimate);
  return { entryZone:[entryLow,entryHigh],secondaryZone:[resistance+atr*.5,resistance+atr],stopLoss,tp1,tp2,tp3,riskReward,adjustedRisk,position:{accountBalance:balance,riskAmount,stopDistancePercent:stopPercent*100,notional,leverage,estimatedMargin:notional/leverage},liquidationSafety:{estimatedLiquidationPrice,distanceFromStopPercent:(estimatedLiquidationPrice-stopLoss)/stopLoss*100,stopBeforeEstimatedLiquidation:stopLoss<estimatedLiquidationPrice,note:'近似估算；实际强平价受逐仓/全仓、维持保证金阶梯、费用及其他仓位影响，以交易所为准'} };
}
