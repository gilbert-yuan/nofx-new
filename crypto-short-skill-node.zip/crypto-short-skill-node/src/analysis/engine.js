import { summarizeIndicators, zScore } from '../indicators/core.js';
import { structure } from './structure.js';
import { clamp, last, pct, round } from '../utils.js';
import { makeTradePlan } from '../risk/plan.js';

const R=(o)=>Object.fromEntries(Object.entries(o).map(([k,v])=>[k,typeof v==='number'?round(v):v]));
function derivatives(m) {
  const funding=m.funding.map(x=>Number(x.fundingRate));
  const oi=m.oi.map(x=>Number(x.sumOpenInterestValue));
  const global=m.globalRatio?.at(-1), top=m.topRatio?.at(-1), taker=m.takerRatio?.at(-1);
  const markPrice=Number(m.premium.markPrice), indexPrice=Number(m.premium.indexPrice);
  return { markPrice,indexPrice,basisPercent:pct(markPrice,indexPrice)*100,fundingRate:Number(m.premium.lastFundingRate),nextFundingTime:Number(m.premium.nextFundingTime),fundingZ:zScore(funding),oiChange15m:oi.length>1?pct(last(oi),oi.at(-2)):0,oiChange4h:oi.length>16?pct(last(oi),oi.at(-17)):null,globalLongShortRatio:global?Number(global.longShortRatio):null,topTraderLongShortRatio:top?Number(top.longShortRatio):null,takerBuySellRatio:taker?Number(taker.buySellRatio):null };
}
function regime(i,s){
  if(i.atrPercentile>.9)return 'HIGH_VOLATILITY';
  if(s.trend==='BEARISH'&&i.ema20<i.ema50&&i.ema50<i.ema200)return 'TREND_DOWN';
  if(s.trend==='BULLISH'&&i.ema20>i.ema50&&i.ema50>i.ema200)return 'TREND_UP';
  if(i.atrPercentile<.2)return 'LOW_VOLATILITY'; return 'RANGE';
}
export function analyzeMarket(market, btcMarket, options={}) {
  const tfs={}; for(const [tf,c] of Object.entries(market.candles)) tfs[tf]={ indicators:summarizeIndicators(c), structure:structure(c) };
  const btcI=summarizeIndicators(btcMarket.candles['4h']), btcS=structure(btcMarket.candles['4h']);
  const d=derivatives(market), i=tfs['4h'].indicators, s4=tfs['4h'].structure, s1=tfs['1h'].structure, s15=tfs['15m'].structure;
  const marketRegime=regime(i,s4); const distanceAtr=(i.price-i.ema20)/(i.atr||1);
  const squeezeRisk=(d.fundingZ<-2&&d.oiChange15m>0&&pct(i.price,market.candles['4h'].at(-5).close)>=0)||(s4.trend==='BULLISH'&&i.volumeRatio>1.5&&d.oiChange15m>0)?'HIGH':d.fundingZ<-1?'MEDIUM':'LOW';
  const btcEnvironment=btcS.trend;
  let score=0, reasons=[];
  if(s4.trend==='BEARISH'){score+=20;reasons.push('4H形成LH+LL');}
  if(s1.trend==='BEARISH'){score+=15;reasons.push('1H空头结构');}
  if(s15.chochBearish&&s15.bosBearish){score+=10;reasons.push('15m CHOCH+BOS确认');}
  const nearResistance=s1.resistance&&Math.abs(i.price-s1.resistance)<=1.2*i.atr;
  if(nearResistance||s15.failedBreakout){score+=10;reasons.push('价格接近阻力或出现假突破');}
  if(i.price<i.ema20&&i.ema20<i.ema50&&i.ema50<i.ema200){score+=10;reasons.push('EMA空头排列');}
  if(i.volumeRatio>1.1&&i.takerSellRatio>.5)score+=10;
  if(d.fundingZ>1)score+=5;
  if(d.oiChange15m>0&&pct(i.price,market.candles['4h'].at(-2).close)<0)score+=5;
  if(btcEnvironment==='BEARISH')score+=5; else if(btcEnvironment==='BULLISH')score-=15;
  let entryQuality=50;
  if(nearResistance)entryQuality+=15; if(s15.chochBearish)entryQuality+=12; if(s15.bosBearish)entryQuality+=8; if(s15.failedBreakout)entryQuality+=10;
  if(distanceAtr<-2)entryQuality-=35; if(i.rsi<30)entryQuality-=20; if(i.atrPercentile>.9)entryQuality-=15;
  entryQuality=clamp(entryQuality,0,100); score=clamp(score,0,90);
  const plan=makeTradePlan({price:i.price,atr:i.atr,resistance:s1.resistance||s4.resistance,support:s4.support||s1.support,balance:options.balance??10000,risk:options.risk??.01,volatility:i.atrPercentile,leverage:options.leverage??5});
  if(plan.riskReward>=3)score+=10; else if(plan.riskReward>=2)score+=7;
  score=clamp(score,0,100);
  let decision='SHORT_ALLOWED', state='SHORT_TRIGGERED';
  const blockers=[];
  if(marketRegime==='TREND_UP'){decision='HOLD';state='NO_SETUP';blockers.push('4H强上涨趋势');}
  else if(squeezeRisk==='HIGH'){decision='HOLD';state='RISK_OFF';blockers.push('挤空风险高');}
  else if(score<70){decision='HOLD';state='NO_SETUP';blockers.push('空头评分不足70');}
  else if(distanceAtr<=-2||entryQuality<70){decision='WAIT_FOR_PULLBACK';state='WAITING_PULLBACK';blockers.push('当前位置不适合追空');}
  else if(plan.riskReward<2){decision='HOLD';state='NO_SETUP';blockers.push('预期盈亏比低于1:2');}
  else if(!(s15.chochBearish&&s15.bosBearish)){decision='WAIT_FOR_CONFIRMATION';state='WAITING_CONFIRMATION';blockers.push('等待15m CHOCH+BOS');}
  const risks=[]; if(i.atrPercentile>.8)risks.push('波动率偏高，应降低仓位'); if(btcEnvironment==='BULLISH')risks.push('BTC 4H偏多'); if(i.rsi<30)risks.push('RSI超卖，存在反弹风险'); if(d.oiChange15m<0)risks.push('OI下降，当前下跌可能以平仓为主');
  return { symbol:market.symbol,contract:{market:'Binance USD-M Futures',contractType:market.contract.contractType,marginAsset:market.contract.marginAsset,status:market.contract.status,pricePrecision:market.contract.pricePrecision,quantityPrecision:market.contract.quantityPrecision},generatedAt:new Date().toISOString(),dataQuality:'GOOD',decision,state,marketRegime,bearishProbability:score,entryQuality,squeezeRisk,btcEnvironment,currentPrice:round(i.price),markPrice:round(d.markPrice),indexPrice:round(d.indexPrice),doNotChaseBelow:round(i.ema20-2*i.atr),primaryShortZone:plan.entryZone.map(x=>round(x)),secondaryShortZone:plan.secondaryZone.map(x=>round(x)),confirmationRequired:'15m CHOCH + BOS + Retest',stopLoss:round(plan.stopLoss),tp1:round(plan.tp1),tp2:round(plan.tp2),tp3:round(plan.tp3),riskReward:round(plan.riskReward,2),suggestedRisk:round(plan.adjustedRisk*100,2)+'%',position:R(plan.position),liquidationSafety:R(plan.liquidationSafety),invalidation:`1H/4H收盘有效突破 ${round(plan.stopLoss)}`,indicators:{'4h':R(i),'1h':R(tfs['1h'].indicators),'15m':R(tfs['15m'].indicators)},derivatives:R(d),structure:{'4h':s4.trend,'1h':s1.trend,'15m':s15.trend,choch15m:s15.chochBearish,bos15m:s15.bosBearish},mainReasons:reasons,blockers,risks,finalConclusion:decision==='SHORT_ALLOWED'?'现在满足做空条件，但仍须按止损执行':decision==='WAIT_FOR_PULLBACK'?'方向可能偏空，但等待反弹，禁止追空':decision==='WAIT_FOR_CONFIRMATION'?'等待15分钟结构确认':'现在不值得做空，HOLD'};
}
