export function pivots(c, left=3, right=3) {
  const highs=[], lows=[];
  for(let i=left;i<c.length-right;i++){
    const w=c.slice(i-left,i+right+1);
    if(w.every((x,j)=>j===left||x.high<c[i].high)) highs.push({index:i,price:c[i].high,time:c[i].openTime});
    if(w.every((x,j)=>j===left||x.low>c[i].low)) lows.push({index:i,price:c[i].low,time:c[i].openTime});
  }
  return { highs, lows };
}
export function structure(c) {
  const p=pivots(c), h=p.highs.slice(-2), l=p.lows.slice(-2);
  const highPattern=h.length<2?'NA':h[1].price<h[0].price?'LH':'HH';
  const lowPattern=l.length<2?'NA':l[1].price<l[0].price?'LL':'HL';
  const trend=highPattern==='LH'&&lowPattern==='LL'?'BEARISH':highPattern==='HH'&&lowPattern==='HL'?'BULLISH':'NEUTRAL';
  const lastClose=c.at(-1).close, priorHL=l.at(-1)?.price, priorHH=h.at(-1)?.price;
  const bosBearish=priorHL!=null && lastClose<priorHL;
  const failedBreakout=h.length>=2 && c.slice(-8).some(x=>x.high>h[0].price&&x.close<h[0].price);
  return { trend, highPattern, lowPattern, bosBearish, chochBearish:bosBearish&&highPattern==='LH', failedBreakout, resistance:h.at(-1)?.price??null, support:l.at(-1)?.price??null, pivots:p };
}
