# Crypto Short Skill Node.js

专用于 Binance U 本位永续合约，把“4H找空头趋势 → 等反弹 → 1H找压力 → 15m确认转弱 → 再开空”的 Skill 转成确定性 Node.js 引擎。

## 环境

- Node.js 20+
- 可访问 Binance USDⓈ-M Futures 公共 API
- 无需 API Key，不包含下单功能

## 使用

```bash
npm run analyze -- PROMUSDT
npm run analyze -- PROMUSDT --balance 10000 --risk 0.01 --leverage 5 --json
npm run backtest -- PROMUSDT --limit 1000
npm test
```

程序会先验证交易对确实是处于交易状态的 U 本位永续合约，并分析标记价格、指数价格、基差、Funding、OI、全市场与大户多空比、主动买卖比。输出会明确给出 `SHORT_ALLOWED`、`WAIT_FOR_PULLBACK`、`WAIT_FOR_CONFIRMATION` 或 `HOLD`。即使方向偏空，入场质量不足也不会强行输出做空。

## 说明

程序采用已收盘与当前返回的公开合约数据进行规则分析，不会自动交易。强平价只是近似安全检查；实际结果受保证金模式、风险限额、费用和其他仓位影响。基础回测已计入手续费和滑点，但它是研究工具，不等于未来收益保证。
