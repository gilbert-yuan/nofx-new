---
name: analyze-crypto-short
description: Analyze Binance USD-M perpetual symbols for evidence-based short setups using 4H/1H/15m/5m structure, BTC context, EMA, RSI, ATR, ADX, volume, funding, open interest, entry quality, risk/reward, and strict HOLD rules. Use when the user asks whether a crypto futures symbol is worth shorting or requests entry, stop-loss, take-profit, risk, invalidation, or backtest analysis.
---

# Crypto short analysis

Run the deterministic engine before writing any conclusion:

```bash
npm run analyze -- <SYMBOL> [--balance 10000] [--risk 0.01] [--json]
```

Treat its structured output as authoritative for prices, indicators, scores and state. Never invent unavailable market data. If `dataQuality` is not `GOOD`, answer `HOLD` and list missing data.

Apply these non-negotiable rules:

- Separate bearish direction from entry quality.
- Prefer `HOLD` or `WAIT` when evidence is weak.
- Never short a strong 4H uptrend, abnormal squeeze risk, an extended move below EMA20, directly above support, or expected RR below 1:2.
- Require 15m bearish confirmation before `SHORT_ALLOWED`.
- Size positions from account risk and stop distance, never from leverage.
- State the invalidation level and disclose that the result is analytical, not guaranteed.

Use `npm run backtest -- <SYMBOL>` when the user explicitly requests historical validation. Read [references/rules.md](references/rules.md) when explaining scoring or state transitions.
