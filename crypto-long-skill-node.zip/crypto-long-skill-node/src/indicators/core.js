import { mean, stdev, quantileRank } from '../utils.js';

export function ema(values, period) {
  const out = Array(values.length).fill(null);
  if (values.length < period) return out;
  let prev = mean(values.slice(0, period)); out[period - 1] = prev;
  const k = 2 / (period + 1);
  for (let i = period; i < values.length; i++) { prev = values[i] * k + prev * (1 - k); out[i] = prev; }
  return out;
}
export function rsi(values, period = 14) {
  const out = Array(values.length).fill(null); if (values.length <= period) return out;
  let gain = 0, loss = 0;
  for (let i = 1; i <= period; i++) { const d = values[i] - values[i-1]; gain += Math.max(d,0); loss += Math.max(-d,0); }
  gain /= period; loss /= period; out[period] = loss === 0 ? 100 : 100 - 100/(1+gain/loss);
  for (let i=period+1;i<values.length;i++) { const d=values[i]-values[i-1]; gain=(gain*(period-1)+Math.max(d,0))/period; loss=(loss*(period-1)+Math.max(-d,0))/period; out[i]=loss===0?100:100-100/(1+gain/loss); }
  return out;
}
export function trueRanges(c) { return c.map((x,i) => i ? Math.max(x.high-x.low, Math.abs(x.high-c[i-1].close), Math.abs(x.low-c[i-1].close)) : x.high-x.low); }
export function atr(c, period=14) { return ema(trueRanges(c), period); }
export function macd(values, fast=12, slow=26, signal=9) {
  const f=ema(values,fast), s=ema(values,slow); const line=values.map((_,i)=>f[i]==null||s[i]==null?null:f[i]-s[i]);
  const valid=line.filter(x=>x!=null), sigValid=ema(valid,signal); let j=0;
  const sig=line.map(x=>x==null?null:sigValid[j++]); return { line, signal:sig, histogram:line.map((x,i)=>x==null||sig[i]==null?null:x-sig[i]) };
}
export function adx(c, period=14) {
  const tr=trueRanges(c), plus=[0], minus=[0];
  for(let i=1;i<c.length;i++){ const up=c[i].high-c[i-1].high, dn=c[i-1].low-c[i].low; plus.push(up>dn&&up>0?up:0); minus.push(dn>up&&dn>0?dn:0); }
  const a=ema(tr,period), p=ema(plus,period), m=ema(minus,period);
  const pdi=c.map((_,i)=>a[i]?100*p[i]/a[i]:null), mdi=c.map((_,i)=>a[i]?100*m[i]/a[i]:null);
  const dx=c.map((_,i)=>pdi[i]==null?null:100*Math.abs(pdi[i]-mdi[i])/(pdi[i]+mdi[i]||1));
  const valid=dx.filter(x=>x!=null), av=ema(valid,period); let j=0; const ax=dx.map(x=>x==null?null:av[j++]);
  return { adx:ax, plusDI:pdi, minusDI:mdi };
}
export function zScore(values) { const m=mean(values), s=stdev(values); return s ? (values.at(-1)-m)/s : 0; }
export function summarizeIndicators(c) {
  const close=c.map(x=>x.close), volume=c.map(x=>x.volume), e20=ema(close,20), e50=ema(close,50), e200=ema(close,200), a=atr(c), rs=rsi(close), mc=macd(close), ax=adx(c);
  const currentAtr=a.at(-1); const atrWindow=a.filter(x=>x!=null).slice(-200);
  return { price:close.at(-1), ema20:e20.at(-1), ema50:e50.at(-1), ema200:e200.at(-1), ema20Slope:e20.at(-1)-e20.at(-6), ema50Slope:e50.at(-1)-e50.at(-6), atr:currentAtr, atrPercentile:quantileRank(atrWindow,currentAtr), rsi:rs.at(-1), macd:mc.line.at(-1), macdSignal:mc.signal.at(-1), macdHistogram:mc.histogram.at(-1), adx:ax.adx.at(-1), plusDI:ax.plusDI.at(-1), minusDI:ax.minusDI.at(-1), volumeRatio:volume.at(-1)/(mean(volume.slice(-20))||1), volumeZ:zScore(volume.slice(-100)), takerSellRatio:1-(c.at(-1).takerBuyVolume/(c.at(-1).volume||1)) };
}
