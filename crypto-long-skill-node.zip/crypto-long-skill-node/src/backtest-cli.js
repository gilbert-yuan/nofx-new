#!/usr/bin/env node
import config from '../config.json' with {type:'json'};
import { BinanceFutures } from './api/binance.js';
import { backtest } from './backtest/engine.js';
import { parseArgs } from './utils.js';
const args=parseArgs(process.argv.slice(2)); if(!args.symbol){console.error('用法: npm run backtest -- PROMUSDT [--limit 1000]');process.exit(2);}
try{const api=new BinanceFutures(config.apiBase),c=await api.klines(args.symbol,'1h',Math.min(args.limit,1500));console.log(JSON.stringify(backtest(c),null,2));}catch(e){console.error(e.message);process.exit(1);}
