#!/usr/bin/env node
import { analyze } from './index.js';
import { formatReport } from './report/text.js';
import { parseArgs } from './utils.js';
const args=parseArgs(process.argv.slice(2));
if(!args.symbol){console.error('用法: npm run analyze -- PROMUSDT [--balance 10000] [--risk 0.01] [--leverage 5] [--json]');process.exit(2);}
try { const result=await analyze(args.symbol,args); console.log(args.json?JSON.stringify(result,null,2):formatReport(result)); }
catch(error){ console.error(JSON.stringify({symbol:args.symbol,dataQuality:'BAD',decision:'HOLD',finalConclusion:'数据获取失败，现在不值得做多，HOLD',error:error.message},null,2)); process.exit(1); }
