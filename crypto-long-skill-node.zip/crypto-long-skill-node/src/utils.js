export const clamp = (x, lo, hi) => Math.min(hi, Math.max(lo, x));
export const mean = a => a.length ? a.reduce((s, x) => s + x, 0) / a.length : null;
export const stdev = a => {
  if (a.length < 2) return 0;
  const m = mean(a);
  return Math.sqrt(mean(a.map(x => (x - m) ** 2)));
};
export const pct = (a, b) => b ? (a - b) / b : 0;
export const round = (x, n = 6) => Number.isFinite(x) ? Number(x.toFixed(n)) : null;
export const last = a => a[a.length - 1];
export const quantileRank = (values, current) => values.length ? values.filter(v => v <= current).length / values.length : 0;

export function parseArgs(argv) {
  const out = { symbol: null, balance: 10000, risk: 0.01, leverage: 5, json: false, limit: 1000 };
  for (let i = 0; i < argv.length; i++) {
    const v = argv[i];
    if (!v.startsWith('--') && !out.symbol) out.symbol = v.toUpperCase();
    else if (v === '--json') out.json = true;
    else if (v === '--balance') out.balance = Number(argv[++i]);
    else if (v === '--risk') out.risk = Number(argv[++i]);
    else if (v === '--leverage') out.leverage = Number(argv[++i]);
    else if (v === '--limit') out.limit = Number(argv[++i]);
  }
  return out;
}
