import config from '../config.json' with { type:'json' };
import { BinanceFutures } from './api/binance.js';
import { analyzeMarket } from './analysis/engine.js';
export async function analyze(symbol, options={}) {
  const api=new BinanceFutures(options.apiBase||config.apiBase);
  const [market,btc]=await Promise.all([api.loadMarket(symbol,config.intervals),api.loadMarket('BTCUSDT',config.intervals)]);
  return analyzeMarket(market,btc,options);
}
export { analyzeMarket } from './analysis/engine.js';
