const toCandle = k => ({
  openTime: Number(k[0]), open: Number(k[1]), high: Number(k[2]), low: Number(k[3]),
  close: Number(k[4]), volume: Number(k[5]), closeTime: Number(k[6]), trades: Number(k[8]),
  takerBuyVolume: Number(k[9])
});

export class BinanceFutures {
  constructor(base = 'https://fapi.binance.com') { this.base = base.replace(/\/$/, ''); }
  async get(path, params = {}) {
    const url = new URL(this.base + path);
    Object.entries(params).forEach(([k, v]) => url.searchParams.set(k, String(v)));
    const res = await fetch(url, { headers: { 'user-agent': 'crypto-long-skill-node/1.0' }, signal: AbortSignal.timeout(15000) });
    if (!res.ok) throw new Error(`Binance ${res.status}: ${(await res.text()).slice(0, 200)}`);
    return res.json();
  }
  async klines(symbol, interval, limit = 500) { return (await this.get('/fapi/v1/klines', { symbol, interval, limit })).map(toCandle); }
  async premium(symbol) { return this.get('/fapi/v1/premiumIndex', { symbol }); }
  async exchangeInfo() { return this.get('/fapi/v1/exchangeInfo'); }
  async funding(symbol, limit = 200) { return this.get('/fapi/v1/fundingRate', { symbol, limit }); }
  async oiHistory(symbol, period = '15m', limit = 200) { return this.get('/futures/data/openInterestHist', { symbol, period, limit }); }
  async globalLongShort(symbol, period = '15m', limit = 30) { return this.get('/futures/data/globalLongShortAccountRatio', { symbol, period, limit }); }
  async topLongShort(symbol, period = '15m', limit = 30) { return this.get('/futures/data/topLongShortPositionRatio', { symbol, period, limit }); }
  async takerRatio(symbol, period = '15m', limit = 30) { return this.get('/futures/data/takerlongshortRatio', { symbol, period, limit }); }
  async loadMarket(symbol, intervals) {
    const entries = Object.entries(intervals);
    const [series, premium, funding, oi, globalRatio, topRatio, takerRatio, info] = await Promise.all([
      Promise.all(entries.map(async ([tf, limit]) => [tf, await this.klines(symbol, tf, limit)])),
      this.premium(symbol), this.funding(symbol), this.oiHistory(symbol),
      this.globalLongShort(symbol), this.topLongShort(symbol), this.takerRatio(symbol), this.exchangeInfo()
    ]);
    const contract = info.symbols.find(x => x.symbol === symbol);
    if (!contract) throw new Error(`${symbol} 不是 Binance U本位合约交易对`);
    if (contract.contractType !== 'PERPETUAL') throw new Error(`${symbol} 不是永续合约（${contract.contractType}）`);
    if (contract.status !== 'TRADING') throw new Error(`${symbol} 当前合约状态为 ${contract.status}`);
    return { symbol, contract, candles: Object.fromEntries(series), premium, funding, oi, globalRatio, topRatio, takerRatio };
  }
}
