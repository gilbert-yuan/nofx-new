# Rule reference

## Decision order

1. Bad/missing data → `HOLD`.
2. Strong 4H downtrend → `HOLD`.
3. High long-liquidation risk or extreme market → `HOLD`.
4. Bullish score below 70 → `HOLD`.
5. Price more than 2 ATR above EMA20 → `WAIT_FOR_PULLBACK`.
6. Entry quality below 70 → `WAIT_FOR_PULLBACK`.
7. Expected RR below 2 → `HOLD`.
8. No 15m bullish CHOCH/BOS → `WAIT_FOR_CONFIRMATION`.
9. Otherwise → `LONG_ALLOWED`.

## Score weights

- 4H bullish trend 20; 1H bullish structure 15; 15m confirmation 10.
- Resistance confluence 10; EMA alignment 10; volume 10.
- Funding 5; open interest 5; BTC environment 5; RR 10.

## Risk

Risk amount = balance × risk rate. Position notional = risk amount ÷ stop-distance percentage. Reduce risk in high volatility. Never use leverage to increase the accepted loss.
