# Crypto Long Skill Node.js

专用于 Binance U 本位永续合约的做多分析：4H多头趋势 → 等待回踩 → 1H寻找支撑 → 15m结构转强 → 才允许做多。

## 环境与运行

- Node.js 20+；无需第三方依赖或 API Key；不包含自动下单。

```bash
npm test
npm run analyze -- PROMUSDT
npm run analyze -- PROMUSDT --balance 10000 --risk 0.01 --leverage 5 --json
npm run backtest -- PROMUSDT --limit 1000
```

程序验证 U 本位永续合约，并分析4H/1H/15m/5m、BTC环境、EMA/RSI/ATR/ADX/MACD、成交量、标记/指数价格、基差、Funding、OI、多空比和主动买卖比。输出 `LONG_ALLOWED`、`WAIT_FOR_PULLBACK`、`WAIT_FOR_CONFIRMATION` 或 `HOLD`。

强平价为近似安全检查；实际值受逐仓/全仓、维持保证金阶梯、费用和其他持仓影响。回测计入手续费与滑点，但历史表现不保证未来收益。
